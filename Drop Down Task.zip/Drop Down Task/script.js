var itemsArray = JSON.parse(localStorage.getItem("itemsArray")) || [];
function validation() {
  let id = document.getElementById("textid").value;
  if (id == "") {
    window.alert("Please Enter Id First");
    id.focus();
    return false;
  }
}
function uuidv4() {
  return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
    (
      c ^
      (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))
    ).toString(16)
  );
}
function add() {
  validation();
  let id = document.getElementById("textid").value;
  let element = document.getElementById("form").element.value;
  let addItems = document.createElement("input");
  addItems.setAttribute("type", element);
  addItems.setAttribute("name", element);
  addItems.setAttribute("id", element);
  let Table = document.getElementById("tableId");
  var row = Table.insertRow(1);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  var cell3 = row.insertCell(2);
  var cell4 = row.insertCell(3);
  cell1.innerHTML = id;
  cell2.appendChild(addItems);
  let btnSub = document.createElement("button");
  btnSub.innerHTML = "Save";
  btnSub.setAttribute("onclick", "save()");
  cell3.appendChild(btnSub);
  var btnRm = document.createElement("button");
  btnRm.innerHTML = "Remove";
  cell4.appendChild(btnRm);
  btnRm.setAttribute("onclick", "remove(this)");
  localStorage.setItem("itemsArray", JSON.stringify(itemsArray));
}
function save() {
  var elementId = document.getElementById("textid").value;
  var dropdownItems = document.getElementById("select");
  var dropdownValue = dropdownItems.options[dropdownItems.selectedIndex].value;
  let obj = {
    id: elementId,
    dropdown: dropdownValue,
  };
  console.log(obj);
  itemsArray.push(obj);
  localStorage.setItem("itemsArray", JSON.stringify(itemsArray));
}

function remove(element) {
  var result = confirm("Are you sure to delete?");
  if (result) {
    let deleteRows = element.parentElement.parentElement.rowIndex;
    document.getElementById("tableId").deleteRow(deleteRows);
    itemsArray.splice(deleteRows - 1);
    localStorage.setItem("itemsArray", JSON.stringify(itemsArray));
  }
}

function insetDataIntoCell() {
  let data = JSON.parse(localStorage.getItem("itemsArray"));
  var displayTable = document.getElementById("tableId");
  for (i = 0; i <= data.length; i++) {
    var row = displayTable.insertRow(1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    cell1.innerHTML = data[i].id;
    cell2.innerHTML = data[i].dropdown;
    let btnSub = document.createElement("button");
    btnSub.innerHTML = "Save";
    cell3.appendChild(btnSub);
    btnSub.setAttribute("onclick", "save()");
    var btnRm = document.createElement("button");
    btnRm.innerHTML = "Remove";
    cell4.appendChild(btnRm);
    btnRm.setAttribute("onclick", "remove(this)");
  }
  localStorage.setItem("itemsArray", JSON.stringify(itemsArray));
}
insetDataIntoCell();
