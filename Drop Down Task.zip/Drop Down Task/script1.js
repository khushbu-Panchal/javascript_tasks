var itemsArray = JSON.parse(localStorage.getItem("itemsArray")) || [];

function validation() {
  let id = document.getElementById("textId").value;
  const findId = itemsArray.find((element) => element.id == id);
  if (id == "") {
    window.alert("Please Enter Id First");
    id.focus();
    return false;
  } else if (findId) {
    window.alert("You Have Enter Duplicate Id");
    id.focus();
  }
}

function setter() {
  localStorage.setItem("itemsArray", JSON.stringify(itemsArray));
}
function uuidv4() {
  return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
    (
      c ^
      (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))
    ).toString(16)
  );
}

function addInput() {
  validation();
  var elementId = document.getElementById("textId").value;
  var dropdownItems = document.getElementById("select");
  var elementType = dropdownItems.options[dropdownItems.selectedIndex].value;
  let obj = {
    id: elementId,
    type: elementType,
    rId: uuidv4(),
    value: "",
  };
  itemsArray.push(obj);
  setter();
  display();
}

function display() {
  var localData = JSON.parse(localStorage.getItem("itemsArray"));
  var table = document.getElementById("displayTable");
  if (table) {
    let str = "";
    if (localData?.length) {
      localData?.forEach((element) => {
        str += `
  <tr>
  <td>${element.id}</td>
  <td><input type="${element.type}" value="${element.value}" id="${element.rId}" class="inputEle"/></td>
  <td><button type="submit" class="btn" onclick="updateInput('${element.rId}')">Save</button></td>
  <td ><button id ="btnRemove"  type="button" class="btn"  onclick="deleteInput('${element.rId}')">Remove</button></td>
  </tr>
  `;
        table.innerHTML = str;
      });
    }
  }
}

function updateInput(element) {
  console.log(element, "element");
  const index = itemsArray.findIndex((ele) => ele.rId === element);
  itemsArray[index].value = document.getElementById(element).value;
  setter();
}

function deleteInput(rId) {
  const findData = itemsArray.findIndex((element) => element.rId == rId);
  itemsArray.splice(findData, 1);
  if (document.getElementById("btnRemove").onclick) {
    alert("Sure, Are You Want To Delete");
  }
  setter();
  window.location.reload();
}
function resetInput() {
  document.getElementById("textId").value = "";
  document.getElementById("select").value = "";
}
display();
