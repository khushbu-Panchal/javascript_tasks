// formData is accessible here as we have global variable in formData.js
class Main {
  constructor(formContainerId, storageId, tableDiv,) {
    // formContainerId, storageId, tableContainerId will be in argument of constructor
    // start code to init and link form.js, storage.js, table.js
    const form = new Form(); // form js class to create form and access its methods
    form.createForm(formContainerId);
    const storage = new Storage(); // storage class to access storage methods
    const table = new Table();
    table.createTable(tableDiv) // table js class to create table and access its methods
    console.log(formData, form, storage, table, 'Printed all instance of the class to remove eslint error');
  }
}
//formContainerId: HTML Div element id inside of which you want to create form4
// formContainerId -> #employeeForm of current index.html

// storageId: localStorage key for saving json  string data init
// storageId -> 'employeeData' simple string to selected as key of localStorage

//tableContainerId: HTML Div element id inside of which you want to create table
// tableContainerId -> #tableDiv of current index.html

//pass formContainerId, storageId, tableContainerId to Main(formContainerId, storageId, tableContainerId)
const main = new Main('formContainerId', 'storageId', 'tableDiv');
console.log(main);
