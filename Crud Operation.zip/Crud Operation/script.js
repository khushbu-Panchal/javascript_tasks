var itemsArray = JSON.parse(localStorage.getItem("itemsArray")) || [];
var chkarray = [];
var editingItem;
function validateForm() {
  const form = document.forms["myForm"];
  let name = form["fname"].value;
  var getSelectedValue = document.querySelector('input[name="gender"]:checked');
  let dob1 = form["dob"].value;
  let mail = form["email"].value;
  let contact = document.getElementById("phone").value;
  let pho1 = /^[1-9]{1}[0-9]{9}$/;
  if (
    name != "" &&
    getSelectedValue != "" &&
    dob1 != "" &&
    mail != "" &&
    contact != "" &&
    dance != "" &&
    sing != "" &&
    chess != ""
  ) {
    if (!name) {
      testIsError = true;
      document.getElementById("errfname").innerHTML = "Enter Your Name";
      return false;
    } else {
      testIsError = false;
      document.getElementById("errfname").innerHTML = "";
    }
    if (getSelectedValue == null) {
      testIsError = true;
      document.getElementById("errgender").innerHTML = "Enter Your Gender";
      return false;
    } else {
      testIsError = false;
      document.getElementById("errgender").innerHTML = "";
    }
    if (dob1 == "" || dob1 == null) {
      testIsError = true;
      document.getElementById("errfdob").innerHTML = "Enter Your Birth Date";
      return false;
    } else {
      testIsError = false;
      document.getElementById("errfdob").innerHTML = "";
    }
    if (mail == "" || mail == null) {
      testIsError = true;
      document.getElementById("erremail").innerHTML = "Enter Your Email";
      return false;
    } else {
      testIsError = false;
      document.getElementById("erremail").innerHTML = "";
    }
    if (contact == "") {
      testIsError = true;
      document.getElementById("errphone").innerHTML = "Enter Your Phone Number";
      return false;
    } else if (!contact.match(pho1)) {
      testIsError = true;
      document.getElementById("errphone").innerHTML =
        "Enter Your Valid Phone Number";
      ("Enter Your Valid Phone Number");
    } else {
      testIsError = false;
      document.getElementById("errphone").innerHTML = "";
    }
    if (document.getElementById("dance").checked) {
      testIsError = false;
      document.getElementById("errhobby").innerHTML = "";
      return false;
    } else if (document.getElementById("sing").checked) {
      testIsError = false;
      document.getElementById("errhobby").innerHTML = "";
      return false;
    } else if (document.getElementById("chess").checked) {
      testIsError = false;
      document.getElementById("errhobby").innerHTML = "";
      return false;
    } else testIsError = true;
    document.getElementById("errhobby").innerHTML = "Enter Your Hobby";
  } else {
    alert("All Fields Are Required");
  }
}

function uuidv4() {
  return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
    (
      c ^
      (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))
    ).toString(16)
  );
}

function onFormSubmit() {
  validateForm();
  if (!testIsError) {
    var fname = document.getElementById("fname").value;
    var dob = document.getElementById("dob").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var gender = document.getElementsByName("gender");
    var chk = document.getElementsByName("hobby");
    var selected = Array.from(gender).find((gender) => gender.checked);
    for (var i = 0; i < chk.length; i++) {
      if (chk[i].checked == true) {
        chkarray.push(chk[i].value);
      }
    }
    let obj = {
      firstName: fname,
      gender: selected?.value,
      dob: dob,
      email: email,
      phone: phone,
      hobby: chkarray,
      id: uuidv4(),
    };

    itemsArray.push(obj);
    localStorage.setItem("itemsArray", JSON.stringify(itemsArray));
    document.location.reload();
    dispBasicData();
    dispAdvanceData();
  }
}
function insertData() {
  if (editingItem) {
    update();
    console.log("update");
  } else {
    onFormSubmit();
    console.log("submit");
  }
}

function dispBasicData() {
  var dateData = JSON.parse(localStorage.getItem("itemsArray"));
  var basicTable = document.getElementById("tableData");
  if (basicTable) {
    let str = "";
    console.log("dateData", { basicTable, dateData });
    if (dateData?.length) {
      dateData?.forEach((element) => {
        str += `
  <tr>
  <td>${element.firstName}</td>
  <td>${element.gender}</td>
  <td>${element.dob}</td>
  <td>${element.email}</td>
  <td>${element.phone}</td>
  <td>${element.hobby}</td>
  <td><button type="button" id="btnEdit" class="btn" onclick="edit('${element.id}')">Edit</button></td>
  <td ><button  type="button" class="btn" onclick="remove('${element.id}')">Delete</button></td>
  </tr>
  `;
        basicTable.innerHTML = str;
      });
    } else {
      str += ` <tr><td colspan="7"><h3 align="center" style="color:red;" > No Data Found</h3></td></tr>`;
      basicTable.innerHTML = str;
    }
  }
}
function dispAdvanceData() {
  localStorage.getItem("itemsArray", JSON.stringify(itemsArray));
  var retrievedObject = JSON.parse(localStorage.getItem("itemsArray"));
  var tbody = document.getElementById("tableData1");
  if (tbody) {
    var advanceName = "<tr ><th>Name</th>";
    var advanceGender = "<tr ><th>" + "Gender" + "</th>";
    var advanceDob = "<tr ><th>" + "Date Of Birth" + "</th>";
    var advanceEmail = "<tr ><th>" + "Email" + "</th>";
    var advancePhone = "<tr ><th>" + "Phone" + "</th>";
    var advanceHobby = "<tr ><th>" + "Hobby" + "</th>";
    // var advanceBtn = "<tr ><th>" + "id" + "</th>";
    var advanceBtn = "<tr ><th>" + "Action" + "</th>";
    for (var i = 0; i < retrievedObject.length; i++) {
      advanceName += "<td>" + retrievedObject[i].firstName + "</td>";
      advanceGender += "<td>" + retrievedObject[i].gender + "</td>";
      advanceDob += "<td>" + retrievedObject[i].dob + "</td>";
      advanceEmail += "<td>" + retrievedObject[i].email + "</td>";
      advancePhone += "<td>" + retrievedObject[i].phone + "</td>";
      advanceHobby += "<td>" + retrievedObject[i].hobby + "</td>";
      if (i === retrievedObject.length) {
        advanceName = "</tr>";
        advanceGender = "</tr>";
        advanceDob = "</tr>";
        advanceEmail = "</tr>";
        advancePhone = "</tr>";
        advanceHobby = "</tr>";
        // advanceBtn += "<td>" + retrievedObject[i].id + "</td></tr>";
        advanceBtn += "</tr>";
      } else {
        advanceBtn += ` <td><button type="button" id="btnEdit" class="btn"  onclick="edit('${retrievedObject[i].id}')">Edit</button>
      <button  type="button" class="btn"  
      onclick="remove('${retrievedObject[i].id}')">Delete</button></td>`;
      }
    }
    var advanceTable =
      advanceName +
      advanceGender +
      advanceDob +
      advanceEmail +
      advancePhone +
      advanceHobby +
      advanceBtn;
    tbody.innerHTML = advanceTable;
  }
  localStorage.setItem("itemsArray", JSON.stringify(itemsArray));
}
function edit(id) {
  itemJsonArrayStr = localStorage.getItem("itemsArray");
  itemJsonArray = JSON.parse(itemJsonArrayStr);
  var find = itemJsonArray.find((itemsArray) => itemsArray.id === id);
  var checkboxes = document.querySelectorAll("input[type=checkbox]");
  checkboxes.forEach((checkValue) => {
    checkValue.checked = find.hobby?.includes(checkValue.value);
  });
  document.forms["myForm"]["fname"].value = find.firstName;
  document.forms["myForm"]["gender"].value = find.gender;
  document.forms["myForm"]["dob"].value = find.dob;
  document.forms["myForm"]["email"].value = find.email;
  document.forms["myForm"]["phone"].value = find.phone;
  document.forms["myForm"]["hobby"].value = find.checkboxes;
  editingItem = id;
  if (document.getElementById("btnEdit").onclick) {
    document.getElementById("addEmp").innerHTML = "Edit Employee";
  }
}
function update() {
  let hiddenId = editingItem;
  var fname = document.getElementById("fname").value;
  var dob = document.getElementById("dob").value;
  var email = document.getElementById("email").value;
  var phone = document.getElementById("phone").value;
  var gender = document.getElementsByName("gender");
  var chk = document.getElementsByName("hobby");
  var index = itemsArray.findIndex((element) => element.id === hiddenId);
  var findObject = itemsArray.find((element) => element.id === hiddenId);
  var selected = Array.from(gender).find((gender) => gender.checked);
  for (var i = 0; i < chk.length; i++) {
    if (chk[i].checked == true) {
      chkarray.push(chk[i].value);
    }
  }
  itemsArray[index] = {
    firstName: fname,
    gender: selected?.value,
    dob: dob,
    email: email,
    phone: phone,
    hobby: chkarray,
    id: findObject.id,
  };
  itemsArray.push();
  localStorage.setItem("itemsArray", JSON.stringify(itemsArray));
  // document.location.reload();
  dispBasicData();
  dispAdvanceData();
}

function remove(id) {
  var result = confirm("Are you sure to delete?");
  if (result) {
    console.log("Delete", itemsArray);
    itemJsonArrayStr = localStorage.getItem("itemsArray");
    itemJsonArray = JSON.parse(itemJsonArrayStr);
    var find = itemJsonArray.findIndex((itemsArray) => itemsArray.id === id);
    itemsArray.splice(find, 1);
    if (document.getElementsByClassName("btnDel").onclick) {
      alert("Sure, Are You Want To Delete");
    }
    localStorage.setItem("itemsArray", JSON.stringify(itemsArray));
    // document.location.reload();
    dispBasicData();
    dispAdvanceData();
  }
}

dispBasicData();
dispAdvanceData();
